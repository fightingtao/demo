//
//  JHTieLoading.h
//  JHLodingViewDemo
//
//  Created by 简豪 on 16/7/3.
//  Copyright © 2016年 codingMan. All rights reserved.
//

#import "JHLoadingProgress.h"

@interface JHTieLoading : JHLoadingProgress

@end
