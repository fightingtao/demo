//
//  UIDynamitItemView.h
//  JHLodingViewDemo
//
//  Created by 简豪 on 16/7/3.
//  Copyright © 2016年 codingMan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIDynamitItemView : UIView

@end
