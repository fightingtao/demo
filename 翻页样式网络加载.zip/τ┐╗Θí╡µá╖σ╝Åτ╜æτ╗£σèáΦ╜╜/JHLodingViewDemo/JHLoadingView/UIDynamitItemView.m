//
//  UIDynamitItemView.m
//  JHLodingViewDemo
//
//  Created by 简豪 on 16/7/3.
//  Copyright © 2016年 codingMan. All rights reserved.
//

#import "UIDynamitItemView.h"

@implementation UIDynamitItemView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
