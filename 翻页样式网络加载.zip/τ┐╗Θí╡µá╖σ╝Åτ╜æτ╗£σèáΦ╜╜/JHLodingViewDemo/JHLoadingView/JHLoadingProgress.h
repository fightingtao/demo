//
//  JHLoadingProgress.h
//  JHLodingViewDemo
//
//  Created by 简豪 on 16/7/1.
//  Copyright © 2016年 codingMan. All rights reserved.
//

#import <UIKit/UIKit.h>
#define K_IOS_WIDTH [UIScreen mainScreen].bounds.size.width
#define K_IOS_HEIGHT [UIScreen mainScreen].bounds.size.height
@interface JHLoadingProgress : UIView


@property (nonatomic,copy)NSString * showInfoStringWhenLoading;


@end
