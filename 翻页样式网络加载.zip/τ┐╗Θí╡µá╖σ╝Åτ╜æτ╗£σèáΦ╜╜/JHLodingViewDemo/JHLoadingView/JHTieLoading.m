//
//  JHTieLoading.m
//  JHLodingViewDemo
//
//  Created by 简豪 on 16/7/3.
//  Copyright © 2016年 codingMan. All rights reserved.
//

#import "JHTieLoading.h"
#import "UIDynamitItemView.h"
@interface JHTieLoading()<UICollisionBehaviorDelegate>

@property (nonatomic,strong)NSMutableArray *bollArr;
@property (nonatomic,assign) CGPoint topCenter;
@property (nonatomic,strong)UIView * leftLayer;
@property (nonatomic,strong)UIView * rightLayer;
@property (nonatomic,strong)UIDynamicAnimator * animor;
@end


@implementation JHTieLoading

-(instancetype)initWithFrame:(CGRect)frame{
    
    if (self = [super initWithFrame:frame]) {
        [self configBaseView];
    }
    return self;
}



- (void)configBaseView{
    
    
    
    _bollArr = [NSMutableArray array];
    CGFloat wid = 20;
    CGFloat begin = (K_IOS_WIDTH - wid * 2)/2;
    _topCenter = CGPointMake(K_IOS_WIDTH/2, 130);
    
    _leftLayer = [[UIView alloc] initWithFrame:CGRectMake(0, 0, wid, wid)];
    _leftLayer.frame = CGRectMake(0, 0, wid, wid);
    _leftLayer.center = CGPointMake(K_IOS_WIDTH / 2, 230);
    _leftLayer.backgroundColor = [UIColor orangeColor];
    _leftLayer.layer.cornerRadius = wid / 2;
    _leftLayer.layer.masksToBounds = YES;
    
    [_leftLayer.layer addObserver:self forKeyPath:@"position" options:NSKeyValueObservingOptionNew context:nil];
    UIBezierPath *path = [UIBezierPath bezierPath];

    
    [path addArcWithCenter:_topCenter radius:100 startAngle:-M_PI-0.5 endAngle:-M_PI/2 * 3 clockwise:NO];
    [self addSubview:_leftLayer];
    
    CAKeyframeAnimation * leftCirAnimation = [CAKeyframeAnimation animationWithKeyPath:@"position"];
    leftCirAnimation.path = path.CGPath;
    leftCirAnimation.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut];
    leftCirAnimation.fillMode = kCAFillModeForwards;
    leftCirAnimation.removedOnCompletion = NO;
    leftCirAnimation.repeatCount = 1;
    leftCirAnimation.duration = 3.0f;
    leftCirAnimation.autoreverses = NO;
    [_leftLayer.layer addAnimation:leftCirAnimation forKey:@"po"];
    
    
    
    _rightLayer = [[UIView alloc] initWithFrame:CGRectMake(0, 0, wid, wid)];
    _rightLayer.center = CGPointMake(K_IOS_WIDTH / 2, 230);
    _rightLayer.backgroundColor = [UIColor orangeColor];
    _rightLayer.layer.cornerRadius = wid / 2;
    _rightLayer.layer.masksToBounds = YES;
    [_rightLayer.layer addObserver:self forKeyPath:@"position" options:NSKeyValueObservingOptionNew context:nil];
    [self addSubview:_rightLayer];
    
}




-(void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary<NSString *,id> *)change context:(void *)context{
    
    
    if ([keyPath isEqualToString:@"position"]) {
        
        
        if (sqrt((_rightLayer.center.x - _leftLayer.center.x)*(_rightLayer.center.x - _leftLayer.center.x) + (_rightLayer.center.y - _leftLayer.center.y)*(_rightLayer.center.y - _leftLayer.center.y))==10) {
            
            
            
            
        }
        
      
    }
    
   
    
    
}











































@end
