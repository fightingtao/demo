# NewsBanner
新闻、公告等文字信息的轮播，支持点击事件。

更新1：修复残影效果。

更新2：修复最后一张和第一张转换时的冲突

最新效果图如下：

![image](https://github.com/ssyzh/NewsBanner/blob/master/NewsBannerDemo/Resource/banner.gif)
