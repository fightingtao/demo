//
//  TaeTest.h
//  ALBBSDK
//
//  Created by 友和(lai.zhoul@alibaba-inc.com) on 14-8-2.
//  Copyright (c) 2014年 com.taobao. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ALBBSDK.h"

@interface ALBBSDK (Test)
/** 重置数据 */
+ (void)reset;
@end
