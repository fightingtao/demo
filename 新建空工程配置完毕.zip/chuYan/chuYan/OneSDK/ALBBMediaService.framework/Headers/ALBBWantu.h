//
//  ALBBWantu.h
//  ALBBMediaService
//  旺旺支持群：1327158539
//
//  Created by huamulou on 16/2/20.
//  Copyright © 2016年 Alipay. All rights reserved.
//

#import <ALBBMediaService/ALBBWantuService.h>
#import <ALBBMediaService/ALBBWTModel.h>
