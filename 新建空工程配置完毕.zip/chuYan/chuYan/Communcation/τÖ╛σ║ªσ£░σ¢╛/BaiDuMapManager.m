//
//  BaiDuMapManager.m
//  BaiDuMap
//
//  Created by cbwl on 16/12/9.
//  Copyright © 2016年 CYT. All rights reserved.
//

#import "BaiDuMapManager.h"
BaiDuMapManager *manager=nil;

@implementation BaiDuMapManager
+(instancetype)shareinstance;{
    if (!manager) {
        static   dispatch_once_t oncetaken;
        dispatch_once(&oncetaken,^{
            manager=[[self alloc]init];
            [manager setMapManager];
        });
    }
    return manager;
}
-(void)setMapManager{
    
    //集成百度地图
    _mapManager = [[BMKMapManager alloc]init];
    // 如果要关注网络及授权验证事件，请设定     generalDelegate参数
    BOOL ret = [_mapManager start:@"XG698WOM8zO6iuqjAzWnDvb6"  generalDelegate:self];
    if (!ret) {
        NSLog(@"baidu manager start failed!");
    }

}
//定位
- (void)locationClick;
{
    //初始化BMKLocationService
    _locService = [[BMKLocationService alloc]init];
    _locService.delegate = self;
    //    _locService.distanceFilter =10.0;
    _locService.desiredAccuracy =kCLLocationAccuracyBest;
    
    //启动LocationService
    [_locService startUserLocationService];
}


- (void)didUpdateUserHeading:(BMKUserLocation *)userLocation
{
    //    NSLog(@"heading is %@",userLocation.heading);
    
}

- (void)didUpdateBMKUserLocation:(BMKUserLocation *)userLocation
{
    [_locService stopUserLocationService];
    
    _staticlat = userLocation.location.coordinate.latitude;
    _staticlng = userLocation.location.coordinate.longitude;
    
    BMKGeoCodeSearch *bmGeoCodeSearch = [[BMKGeoCodeSearch alloc] init];
    bmGeoCodeSearch.delegate = self;
    
    BMKReverseGeoCodeOption *bmOp = [[BMKReverseGeoCodeOption alloc] init];
    bmOp.reverseGeoPoint = userLocation.location.coordinate;
    
    BOOL geoCodeOk = [bmGeoCodeSearch reverseGeoCode:bmOp];
    if (geoCodeOk) {
        NSLog(@"ok");
    }
}

- (void)onGetReverseGeoCodeResult:(BMKGeoCodeSearch *)searcher result:(BMKReverseGeoCodeResult *)result errorCode:(BMKSearchErrorCode)error
{
    BMKAddressComponent *city = result.addressDetail;
    _staticCity = city.city;
    if ([result.poiList count] > 0) {
        BMKPoiInfo *tempAddress = [result.poiList objectAtIndex:0];
        
        _staticAddress = tempAddress.address;
    }else
    {
        _staticAddress = result.address;
    }
    
    
}

- (void)didFailToLocateUserWithError:(NSError *)error
{
//    [[iToast makeText:@"定位失败，请检查是否打开定位服务!"] show];
}


- (void)application:(UIApplication *)application
didFailToRegisterForRemoteNotificationsWithError:(NSError *)error {
    NSLog(@"did Fail To Register For Remote Notifications With Error: %@", error);
}

@end
