//
//  MapRoaldVController.h
//  BBZhongBao
//
//  Created by cbwl on 16/8/30.
//  Copyright © 2016年 CYT. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MapRoaldVController : UIViewController
@property double templatitude;
@property double templongitude;
@property (nonatomic,copy)NSString *address;
@end
