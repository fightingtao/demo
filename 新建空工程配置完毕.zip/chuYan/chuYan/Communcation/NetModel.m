//
//  NetModel.m
//  CYZhongBao
//
//  Created by xc on 15/12/2.
//  Copyright © 2015年 xc. All rights reserved.
//

#import "NetModel.h"

@implementation NetModel

@end

//通用返回model
@implementation Out_AllSameModel

@end



//获取登录验证码
@implementation In_LoginCodeModel

@end

@implementation Out_LoginCodeModel

@end
//-------------------------------------------------------------

//用户登录
@implementation In_LoginModel

@end

@implementation OutLoginBody

@end

@implementation Out_LoginModel

@end
//-------------------------------------------------------------

@implementation  OutPersonerBody

@end
@implementation  Out_personerModel

@end
//-------------------------------------------------------------
@implementation approve_InModel


@end
#pragma mark------------抢单界面－－－－－－－－－－－－－－－－

#pragma mark  发布抢单需求
@implementation In_GrapOrderModel

@end

@implementation  Out_GrapOrderBody

@end

@implementation  Out_GrapOrderModel

@end

#pragma mark 判断是否有抢单权
@implementation  Out_limtsBody

@end

@implementation  Out_limtsModel

@end

#pragma mark 获取最多赔单量

@implementation Out_maxlistBody

@end

@implementation Out_lmaxlistModel

@end

#pragma mark 抢单
@implementation In_GraplistModel

@end
#pragma mark ----------取消订单
@implementation In_cancellModel

@end

#pragma mark ---------通知列表
@implementation In_informModel

@end

@implementation Out_informBody

@end

@implementation Out_informModel

@end




#pragma mark ------------------我的工作首页－－－－－－－－－---
@implementation Out_myHomeWorkBody

@end

@implementation Out_myHomeWorkModel

@end

#pragma mark-----------------订单扫描－－－－－－－－－－－
@implementation In_orderScanModel

@end

#pragma mark ------------ 已扫描订单列表－－－－－－－－－－－－－－－
@implementation Out_orderListBody

@end

@implementation Out_orderListModel

@end


#pragma mark ---------送货列表－－－－－－－－－－－－－－－－

@implementation In_sendGoodsModel

@end

@implementation Out_sendGoodsBody

@end

@implementation Out_sendGoodsModel

@end

#pragma mark-----------------订单详情－－－－－－－－－－－－－
@implementation Out_detialListBody

@end

@implementation Out_detialListModel

@end

#pragma mark----------------配送yi常原因列表－－－－－－－－－
@implementation Out_distributionProblemBody

@end

@implementation Out_distributionProblemModel

@end

#pragma mark--------------------配送反馈－－－－－－－－－－－－
@implementation In_distributionBackModel

@end

#pragma mark ----------------申请提现借口---------------------
@implementation In_applyForMoneyModel

@end


#pragma mark--------------历史订单---------------------
@implementation In_historyOrderModel

@end

@implementation Out_historyOrderBody

@end

@implementation Out_historyOrderModel

@end


#pragma mark---------------账单流水-----------------

@implementation Out_billStreamBody

@end

@implementation Out_billStreamModel

@end

#pragma mark---------------修改绑定手机号-----------------

@implementation In_changePhoneModel


@end

@implementation changeAapprove_InModel


@end

#pragma mark -----------------用户反馈-------------
@implementation In_opinionBackModel
@end

#pragma mark -----------我的钱包
@implementation In_myWalletModel
@end

@implementation  Out_myWalletBody
@end

@implementation  Out_myWalletModel
@end


@implementation  In_payWalletModel: JSONModel

@end
@implementation  Out_payWalletBody: JSONModel

@end
@implementation  Out_payWalletModel: JSONModel

@end
@implementation In_payResultModel

@end

@implementation Out_payResultBody

@end

@implementation Out_payResultModel

@end

@implementation In_GrapDetialListModel

@end

@implementation Out_GrapDetialListBody
@end

@implementation Out_GrapDetialListModel
@end

#pragma mark -----------分拣界面接口-------------
@implementation In_sortModel
@end

@implementation Out_sortModel
@end
