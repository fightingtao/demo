//
//  communcat.m
//  CYZhongBao
//
//  Created by cbwl on 16/8/24.
//  Copyright © 2016年 xc. All rights reserved.
//

#import "communcat.h"
#import "publicResource.h"

@implementation communcat

//
//#pragma mark -----------查看支付结果-------------
//-(void)checkPayInformationWithModel:(In_payResultModel *)payWalletModel  resultDic:(void (^)(NSDictionary *dic))dic{
//    NSMutableDictionary *indic=[[NSMutableDictionary alloc]init];
//    [indic setObject:payWalletModel.key forKey:@"key"];
//    [indic setObject:payWalletModel.digest forKey:@"digest"];
// 
//    [indic setObject:payWalletModel.pay_order_id forKey:@"pay_order_id"];
//    
//    NSString *url=[NSString stringWithFormat:@"%@/crowd-sourcing-consumer/api/v2/pay/query/pay/order",kUrlTest];
//    [self getMessageUsePostWithDic:indic url:url result:^(NSDictionary *resultDic) {
//        dic(resultDic);
//    }];
//}

#pragma mark 网络请求时对AFnetWork的封装
-(void)getMessageUsePostWithDic:(NSDictionary *)dic url:(NSString *)url result:(void(^)(NSDictionary * resultDic))resultDic{
    if ([[dic objectForKey:@"digest"] isEqualToString:@""]) {
        return;
    }
    _manager =[AFHTTPSessionManager manager];
    _manager.responseSerializer=[AFHTTPResponseSerializer serializer];
    
    [_manager POST:url parameters:dic progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        NSString *responseString = [[NSString alloc] initWithBytes:[responseObject bytes] length:[responseObject length] encoding:NSUTF8StringEncoding];
        responseString = [responseString stringByReplacingOccurrencesOfString:@"\r\n" withString:@""];
        responseString = [responseString stringByReplacingOccurrencesOfString:@"\n" withString:@""];
        responseString = [responseString stringByReplacingOccurrencesOfString:@"\t" withString:@""];
        NSData *data=[responseString dataUsingEncoding:NSUTF8StringEncoding];
        
        NSDictionary *dicJson=[NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
        resultDic(dicJson);
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        DLog(@"失败%@",error);
        
    }];
    
}
//#pragma mark 网络请求时对AFnetWork的封装  返回时间
//-(void)getMessageUsePostWithDic:(NSDictionary *)dic url:(NSString *)url date:(void(^)(NSDate * date))date result:(void(^)(NSDictionary * resultDic))resultDic{
//    if ([[dic objectForKey:@"digest"] isEqualToString:@""]) {
//        return;
//    }
//    _manager =[AFHTTPSessionManager manager];
//    _manager.responseSerializer=[AFHTTPResponseSerializer serializer];
//    [_manager POST:url parameters:dic progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
//        NSString *responseString = [[NSString alloc] initWithBytes:[responseObject bytes] length:[responseObject length] encoding:NSUTF8StringEncoding];
//        responseString = [responseString stringByReplacingOccurrencesOfString:@"\r\n" withString:@""];
//        responseString = [responseString stringByReplacingOccurrencesOfString:@"\n" withString:@""];
//        responseString = [responseString stringByReplacingOccurrencesOfString:@"\t" withString:@""];
//        NSData *data=[responseString dataUsingEncoding:NSUTF8StringEncoding];
//        
//        NSDictionary *dicJson=[NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
//        NSHTTPURLResponse *response = (NSHTTPURLResponse *)task.response;
//        NSDictionary *allHeaders = response.allHeaderFields;
//      ;
//    
//        date([self getSysDateFromString:allHeaders[@"Date"]]);
//        resultDic(dicJson);
//        
//        
//    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
//        DLog(@"失败%@",error);
//        
//    }];
//    
//}
//
//#pragma mark -------获取服务器时间-----------
//-(NSDate*)getSysDateFromString:(NSString*)str{
//    
//    NSString* string = [str substringToIndex:25];
//    
//    NSDateFormatter *inputFormatter = [[NSDateFormatter alloc] init];
//    
//    [inputFormatter setLocale:[[NSLocale alloc]
//                               initWithLocaleIdentifier:@"en_US"]];
//    [inputFormatter setDateFormat:@"EEE, dd MMM yyyy HH:mm:ss"];
//    NSDate* inputDate = [inputFormatter dateFromString:string];
//    
//    return inputDate;
//    
//}

#pragma mark ****************************************************
#pragma mark  创建图片
- (UIImage *) createImageWithColor: (UIColor *) color
{
    CGRect rect = CGRectMake(0.0f,0.0f,1.0f,1.0f);
    UIGraphicsBeginImageContext(rect.size);
    CGContextRef context =UIGraphicsGetCurrentContext();
    CGContextSetFillColorWithColor(context, [color CGColor]);
    CGContextFillRect(context, rect);
    UIImage *myImage =UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return myImage;
}


#pragma mark  加密
-(NSString *)hmac:(NSString *)plaintext withKey:(NSString *)key
{
    
    const char *cKey  = [key cStringUsingEncoding:NSASCIIStringEncoding];
    const char *cData = [plaintext cStringUsingEncoding:NSASCIIStringEncoding];
    unsigned char cHMAC[CC_SHA1_DIGEST_LENGTH];
    CCHmac(kCCHmacAlgSHA1, cKey, strlen(cKey), cData, strlen(cData), cHMAC);
    NSData *HMACData = [NSData dataWithBytes:cHMAC length:sizeof(cHMAC)];
    const unsigned char *buffer = (const unsigned char *)[HMACData bytes];
    NSMutableString *HMAC = [NSMutableString stringWithCapacity:HMACData.length * 2];
    for (int i = 0; i < HMACData.length; ++i){
        [HMAC appendFormat:@"%02x", buffer[i]];
    }
    return HMAC;
}
#pragma mark  数组排序 和加密
- (NSString*)ArrayCompareAndHMac:(NSArray*)array
{
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    NSData *userData = [userDefault objectForKey:UserKey];
    UserInfoSaveModel *userInfoModel = [NSKeyedUnarchiver unarchiveObjectWithData:userData];
    // 返回一个排好序的数组，原来数组的元素顺序不会改变
    // 指定元素的比较方法：compare:
    NSString *tempContent = @"";
    NSArray *array2 = [array sortedArrayUsingSelector:@selector(compare:)];
    for (int i = 0; i<[array2 count]; i++) {
        NSString *temp = [array2 objectAtIndex:i];
        tempContent = [NSString stringWithFormat:@"%@%@",tempContent,temp];
    }
    if (userInfoModel&&userInfoModel.key && ![userInfoModel.key isEqualToString:@""]&& userInfoModel.key.length != 0)
    {
        
        const char *cKey  = [userInfoModel.primary_key cStringUsingEncoding:NSASCIIStringEncoding];
        const char *cData = [tempContent cStringUsingEncoding:NSUTF8StringEncoding];
        unsigned char cHMAC[CC_SHA1_DIGEST_LENGTH];
        CCHmac(kCCHmacAlgSHA1, cKey, strlen(cKey), cData, strlen(cData), cHMAC);
        NSData *HMACData = [NSData dataWithBytes:cHMAC length:sizeof(cHMAC)];
        const unsigned char *buffer = (const unsigned char *)[HMACData bytes];
        NSMutableString *HMAC = [NSMutableString stringWithCapacity:HMACData.length * 2];
        for (int i = 0; i < HMACData.length; ++i){
            [HMAC appendFormat:@"%02x", buffer[i]];
        }
        return HMAC;
        
    }else{
        return tempContent;
    }
}
#pragma mark 正则匹配用户身份证号15或18位
- (BOOL)checkUserIdCard: (NSString *) identityCard
{
    BOOL flag;
    if (identityCard.length <= 0) {
        flag = NO;
        return flag;
    }
    NSString *regex2 = @"^(\\d{15}$|^\\d{18}$|^\\d{17}(\\d|X|x))$";
    NSPredicate *identityCardPredicate = [NSPredicate predicateWithFormat:@"SELF MATCHES %@",regex2];
    return [identityCardPredicate evaluateWithObject:identityCard];
}

#pragma mark 验证手机号码
- (BOOL)checkTel:(NSString *)str

{
    if ([str length] == 0) {
        UIAlertView* alert = [[UIAlertView alloc] initWithTitle:NSLocalizedString(@"data_null_prompt", nil) message:NSLocalizedString(@"tel_no_null", nil) delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [alert show];
        return NO;
        
    }
    
    NSString *regex =  @"^1+[3578]+\\d{9}";
    
    NSPredicate *pred = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", regex];
    
    BOOL isMatch = [pred evaluateWithObject:str];
    
    if (!isMatch) {
        
        UIAlertView* alert = [[UIAlertView alloc] initWithTitle:@"提示" message:@"请输入正确的手机号码" delegate:nil cancelButtonTitle:@"好的" otherButtonTitles:nil, nil];
        
        [alert show];
        return NO;
        
    }
    return YES;
}

#pragma mark   md5加密
- (NSString *) getmd5:(NSString *)str

{
    
    const char *cStr = [str UTF8String];
    
    unsigned char result[CC_MD5_DIGEST_LENGTH];
    
    CC_MD5( cStr, strlen(cStr), result );
    
    return [NSString
            
            stringWithFormat: @"%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X",
            
            result[0], result[1],
            
            result[2], result[3],
            
            result[4], result[5],
            
            result[6], result[7],
            
            result[8], result[9],
            
            result[10], result[11],
            
            result[12], result[13],
            
            result[14], result[15]
            
            ];
}

+ (id)sharedInstance
{
    static id sharedInstance;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        sharedInstance = [[[self class] alloc] init];
    });
    
    return sharedInstance;
}
@end
