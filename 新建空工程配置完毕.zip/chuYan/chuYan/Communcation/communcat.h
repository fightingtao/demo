//
//  communcat.h
//  CYZhongBao
//
//  Created by cbwl on 16/8/24.
//  Copyright © 2016年 xc. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "AFHTTPSessionManager.h"
#import "UserInfoSaveModel.h"
#import <UIKit/UIKit.h>
#import <CommonCrypto/CommonHMAC.h>
#import "NetModel.h"
//#import "AFHTTPResponseSerializer.h"
//#import "DataModels.h"
@interface communcat : NSObject
@property (nonatomic,strong)   AFHTTPSessionManager *manager;

+ (id)sharedInstance;
//////////////////////////////////////////////////////////
///颜色创建图片
- (UIImage *) createImageWithColor: (UIColor *) color;
///加密
-(NSString *)hmac:(NSString *)plaintext withKey:(NSString *)key;
///检查手机号
- (BOOL)checkTel:(NSString *)str;
///排序和加密
- (NSString*)ArrayCompareAndHMac:(NSArray*)array;
///md5加密
- (NSString *) getmd5:(NSString *)str;
#pragma 正则匹配用户身份证号15或18位
- (BOOL)checkUserIdCard: (NSString *) idCard;

#pragma mark  快捷登录验证码发送
//-(void)sendCodeWithPhone:(NSString *)phone resultDic:(void(^)(NSDictionary *dic))dic;
//#pragma mark   登录
//-(void)LoginbtnClickWithMsg:(In_LoginModel *)loginInModel  resultDic:(void (^)(NSDictionary *dic))dic;
//
//#pragma mark  个人信息首页
//-(void)getPersonerMsgWithkey:(NSString *)key degist:(NSString *)degist  resultDic:(void (^)(NSDictionary *dic))dic;
//
//#pragma mark 退出登录
//-(void)loginOutClickWithKey:(NSString *)key digest:(NSString *)digest resultDic:(void(^)(NSDictionary *dic))dic;

@end
