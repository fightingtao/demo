//
//  BaiDuMapManager.h
//  BaiDuMap
//
//  Created by cbwl on 16/12/9.
//  Copyright © 2016年 CYT. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

#import <BaiduMapAPI_Base/BMKBaseComponent.h>
#import <BaiduMapAPI_Map/BMKMapComponent.h>
#import <BaiduMapAPI_Location/BMKLocationComponent.h>
#import <BaiduMapAPI_Search/BMKSearchComponent.h>

@interface BaiDuMapManager : NSObject<BMKGeneralDelegate,BMKMapViewDelegate,BMKLocationServiceDelegate,BMKGeoCodeSearchDelegate>
{
    BMKMapManager* _mapManager;
    BMKLocationService* _locService;
}
@property CGFloat staticlng;
@property CGFloat staticlat;
@property (nonatomic, strong) NSString *staticCity;//定位当前城市
@property (nonatomic, strong) NSString *staticAddress;

+(instancetype)shareinstance;
//定位
- (void)locationClick;
@end
