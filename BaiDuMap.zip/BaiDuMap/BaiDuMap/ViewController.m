//
//  ViewController.m
//  BaiDuMap
//
//  Created by cbwl on 16/12/9.
//  Copyright © 2016年 CYT. All rights reserved.
//

#import "ViewController.h"
#import "MapRoaldVController.h"

#import <BaiduMapAPI_Base/BMKBaseComponent.h>
#import <BaiduMapAPI_Map/BMKMapComponent.h>
#import <BaiduMapAPI_Location/BMKLocationComponent.h>
#import <BaiduMapAPI_Search/BMKSearchComponent.h>
#import <BaiduMapAPI_Utils/BMKUtilsComponent.h>

//屏幕宽度和高度
#define SCREEN_WIDTH [[UIScreen mainScreen] bounds].size.width
#define SCREEN_HEIGHT [[UIScreen mainScreen] bounds].size.height

@interface ViewController ()<BMKGeneralDelegate,BMKMapViewDelegate,BMKLocationServiceDelegate,BMKGeoCodeSearchDelegate>
{
    BMKMapManager* _mapManager;
    BMKLocationService* _locService;
}
@property (nonatomic, strong) BMKGeoCodeSearch *searchAdress;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    //集成百度地图
    _mapManager = [[BMKMapManager alloc]init];
    // 如果要关注网络及授权验证事件，请设定     generalDelegate参数
    BOOL ret = [_mapManager start:@"yZULrzYR0sdQLZidMYkfQ6wvOmYHrFYf"  generalDelegate:self];
    if (!ret) {
        NSLog(@"baidu manager start failed!");
    }
    
    UIButton *btn=[UIButton buttonWithType:UIButtonTypeSystem];
    btn.frame=CGRectMake(50, 100, 50, 50);
    btn.backgroundColor=[UIColor redColor];
    [btn addTarget:self action:@selector(btnClick) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btn];
   
}
-(void)btnClick{
    for (int i=0; i<200; i++) {
        [self locationClick];
    }
}
#pragma mark    ------导航按钮点击------ 传入地址--
- (void)locationClick
{
  
    
    _searchAdress =[[BMKGeoCodeSearch alloc]init];
    _searchAdress.delegate = self;
    BMKGeoCodeSearchOption *geoCodeOption = [[BMKGeoCodeSearchOption alloc]init];
    geoCodeOption.address =@"南京市秦淮区四条巷32号";
//    DLog(@"@@@@@@@@@@@@@@@@@@@%@",_tempModel.consigneeaddress);
    BOOL flagAdd = [_searchAdress geoCode:geoCodeOption];
    if(flagAdd)
    {
        NSLog(@"geo检索发送成功");
    }else{
        NSLog(@"geo检索发送失败");
    }
}

#pragma mark 定位
- (void)onGetGeoCodeResult:(BMKGeoCodeSearch *)searcher result:(BMKGeoCodeResult *)result errorCode:(BMKSearchErrorCode)error
{
    if (error == 0) {

        
        BMKPointAnnotation* item = [[BMKPointAnnotation alloc]init];
        item.coordinate = result.location;
        item.title = result.address;
        MapRoaldVController*map =[[MapRoaldVController alloc]init];
        map.address = @"南京市秦淮区四条巷32号";
        map. templatitude = item.coordinate.latitude;
        map.templongitude = item.coordinate.longitude;
        NSLog(@"-----%f    %f",item.coordinate.latitude,item.coordinate.longitude);
        self.hidesBottomBarWhenPushed=YES;
        
        [self.navigationController presentViewController:map animated:YES completion:nil];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
