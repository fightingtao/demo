//
//  tableView.m
//  test
//
//  Created by cbwl on 17/4/1.
//  Copyright © 2017年 CYT. All rights reserved.
//

#import "tableView.h"
#import "CustomAlertView.h"

#import "CYTTableViewCell.h"
@implementation tableView
-(instancetype)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if (self) {
        [self addSubview:self.tableView];
        
    }
    return self;
    
}

-(UITableView*)tableView{
        UITableView *tab = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT) style:UITableViewStylePlain];
        tab.delegate = self;
        tab.dataSource = self;
        //tab.backgroundColor=backGroud;
        
        tab.separatorStyle = UITableViewCellSeparatorStyleNone;
    
    return tab;
}
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section;
{
    return 10;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 1;
    
}
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 20;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *indent=@"cell";
    CYTTableViewCell *cell=[tableView dequeueReusableCellWithIdentifier:indent];
    if(!cell){
        cell=[[CYTTableViewCell alloc]initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:indent];
    }
    cell.selectionStyle=UITableViewCellSelectionStyleNone;
    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    CustomAlertView *alert=  [[CustomAlertView alloc]initWithTitle:@"驳回原因" message:@"请优先选择年级" cancelBtnTitle:@"提交" otherBtnTitle:nil clickIndexBlock:^(NSInteger clickIndex) {
        
        
    }];
    
    [alert showLXAlertView];
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
