//
//  tableView.h
//  test
//
//  Created by cbwl on 17/4/1.
//  Copyright © 2017年 CYT. All rights reserved.
//

#import <UIKit/UIKit.h>
//屏幕宽度和高度
#define SCREEN_WIDTH [[UIScreen mainScreen] bounds].size.width
#define SCREEN_HEIGHT [[UIScreen mainScreen] bounds].size.height

@interface tableView : UIView<UITableViewDelegate,UITableViewDataSource>
@property(nonatomic,strong)UITableView *tableView;
-(instancetype)initWithFrame:(CGRect)frame;


@end
