//
//  CustomAlertView.h
//  CustomAlertView
//
//  Created by 陈彦涛 on 17/4/01.
//  Copyright © 2017年 陈彦涛. All rights reserved.
//

#import <UIKit/UIKit.h>
typedef void(^LXAlertClickIndexBlock)(NSInteger clickIndex);

@interface CustomAlertView : UIView
@property (nonatomic,copy)LXAlertClickIndexBlock clickBlock;


@property (nonatomic,assign)BOOL dontDissmiss;

-(instancetype)initWithTitle:(NSString *)title message:(NSString *)message cancelBtnTitle:(NSString *)cancelTitle otherBtnTitle:(NSString *)otherBtnTitle clickIndexBlock:(LXAlertClickIndexBlock)block;

/**
 *  showLXAlertView
 */
-(void)showLXAlertView;

@end
