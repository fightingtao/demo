//
//  UIView+extension.h

//
//  Created by 陈彦涛 on 17/4/01.
//  Copyright © 2017年 陈彦涛. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIView (extension)

@property (nonatomic, assign) CGFloat x;
@property (nonatomic, assign) CGFloat y;
@property (nonatomic, assign) CGFloat width;
@property (nonatomic, assign) CGFloat height;
@property (nonatomic, assign) CGSize size;
@property (nonatomic, assign) CGFloat centerX;
@property (nonatomic, assign) CGFloat centerY;

@end
