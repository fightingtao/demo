//
//  orderDetail.m
//  coreData
//
//  Created by cbwl on 16/12/9.
//  Copyright © 2016年 CYT. All rights reserved.
//

#import "orderDetail.h"

@implementation orderDetail

@end
