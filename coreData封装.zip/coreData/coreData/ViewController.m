//
//  ViewController.m
//  coreData
//
//  Created by cbwl on 16/12/8.
//  Copyright © 2016年 CYT. All rights reserved.
//

#import "ViewController.h"
#import <CoreData/CoreData.h>
#import "coreDataManger.h"
#import "orderDetail.h"
@interface ViewController ()
//管理对象上下文：相对于数据库本身
@property ( strong, nonatomic) NSManagedObjectContext *managedObjectContext;
//xcdatamodel
@property ( strong, nonatomic) NSManagedObjectModel *managedObjectModel;
//中转站
@property ( strong, nonatomic) NSPersistentStoreCoordinator *persistentStoreCoordinator;
@property (strong,nonatomic)    NSMutableArray *orders;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    NSArray *ary=@[@"查询",@"插入",@"删除"];
    for (int i=0 ;i<3;i++) {
        UIButton *btn=[UIButton buttonWithType:UIButtonTypeSystem];
        btn.frame=CGRectMake(70+40*i, 100, 40, 50);
        [btn setTitle:ary[i] forState:UIControlStateNormal];
        btn.tag=i+10;
        [btn addTarget:self action:@selector(onBtnClick:) forControlEvents:UIControlEventTouchUpInside];
        [self.view addSubview:btn];
    }
    _orders=[NSMutableArray arrayWithCapacity:0];
    for (int i=0; i<200; i++) {
        orderDetail *order=[[orderDetail alloc]init];
        order.name=@"李四";
//        [order setValue:@"小强" forKey:@"name"];
        order.age=@"32";
        order.better=@"789";
        order.height=@"南京市秦淮区四条巷32号";
        [_orders addObject:order];

    }
}
-(void)onBtnClick:(UIButton *)btn{
    if (btn.tag==10) {
//        [self look ];
        [[coreDataManger shareinstance]lookCoreData];
        
    }
    else if (btn.tag==11){
//        [self insertCoreDataObject];
        for (OrderDetail *ord in _orders) {
            [[coreDataManger shareinstance]insertCoreDataObjectWithOrder:ord];

        }

    }
    else if (btn.tag==12){
//        [self delectManager];
        [[coreDataManger shareinstance]delectManager:@"李"];
    }
}
///查询
-(void)look{
    //查询数据
    NSManagedObjectContext *context = [self managedObjectContext];
    //获取表
    NSEntityDescription *entity = [NSEntityDescription entityForName:@"OrderDetail" inManagedObjectContext:context];
    //创建请求
    NSFetchRequest *request = [NSFetchRequest new];
    request.entity = entity;
    //发起请求
    NSArray *arr = [context executeFetchRequest:request error:nil];
    for (NSManagedObject *object in arr) {
        NSString *name = [object valueForKey:@"name"];
        NSNumber *age = [object valueForKey:@"age"];
        NSNumber *sex = [object valueForKey:@"better"];
        NSLog(@"%@ %@ %@",name,age,sex);
        
        
    }
    

}

///添加到数据库
-(void)insertCoreDataObject{
    NSManagedObjectContext *context = self.managedObjectContext;
    //NSEntityDescription实例：数据库中的表
    //NSManagedObject代表一条数据
    NSManagedObject *object = [NSEntityDescription insertNewObjectForEntityForName:@"OrderDetail" inManagedObjectContext:context];
    [object setValue:@"张三" forKey:@"name"];
    [object setValue:@"21" forKey:@"age"];
    [object setValue:@"YES" forKey:@"better"];
    
    NSLog(@"%@",object.class);
    
    [self saveContext];
}


///删除
-(void)delectManager{
    NSManagedObjectContext *context = self.managedObjectContext;
    NSEntityDescription *entity = [NSEntityDescription entityForName:@"OrderDetail" inManagedObjectContext:context];
    NSFetchRequest *request = [NSFetchRequest new];
    request.entity = entity;
    //创建谓词
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"name like '张三'"];
    //将谓词赋予请求
    request.predicate = predicate;
    
    //发送请求
    NSArray *arr = [context executeFetchRequest:request error:nil];
    //遍历数据
    for (NSManagedObject *object in arr) {
        NSLog(@"%@ %@",[object valueForKey:@"name"],[object valueForKey:@"age"]);
    }
    //修改一条数据
    NSManagedObject *object = arr[0];
    //    [object setValue:@"张三21" forKey:@"name"];
    //删除一条数据
    [context deleteObject:object];
    
    [self saveContext];

}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)saveContext
{
    NSError *error = nil;
    NSManagedObjectContext *managedObjectContext = self.managedObjectContext;
    if (managedObjectContext != nil) {
        if ([managedObjectContext hasChanges] && ![managedObjectContext save:&error]) {
            // Replace this implementation with code to handle the error appropriately.
            // abort() causes the application to generate a crash log and terminate. You should not use this function in a shipping application, although it may be useful during development.
            NSLog(@"Unresolved error %@, %@", error, [error userInfo]);
            abort();
        }
    }
}

#pragma mark - Core Data stack

// Returns the managed object context for the application.
// If the context doesn't already exist, it is created and bound to the persistent store coordinator for the application.
- (NSManagedObjectContext *)managedObjectContext
{
    if (_managedObjectContext != nil) {
        return _managedObjectContext;
    }
    
    NSPersistentStoreCoordinator *coordinator = [self persistentStoreCoordinator];
    if (coordinator != nil) {
        _managedObjectContext = [[NSManagedObjectContext alloc] init];
        [_managedObjectContext setPersistentStoreCoordinator:coordinator];
    }
    return _managedObjectContext;
}

// Returns the managed object model for the application.
// If the model doesn't already exist, it is created from the application's model.
- (NSManagedObjectModel *)managedObjectModel
{
    if (_managedObjectModel != nil) {
        return _managedObjectModel;
    }
    NSURL *modelURL = [[NSBundle mainBundle] URLForResource:@"coreData" withExtension:@"momd"];
    _managedObjectModel = [[NSManagedObjectModel alloc] initWithContentsOfURL:modelURL];
    return _managedObjectModel;
}

// Returns the persistent store coordinator for the application.
// If the coordinator doesn't already exist, it is created and the application's store added to it.
- (NSPersistentStoreCoordinator *)persistentStoreCoordinator
{
    if (_persistentStoreCoordinator != nil) {
        return _persistentStoreCoordinator;
    }
    //记录数据库文件存放的位置
    NSURL *storeURL = [[self applicationDocumentsDirectory] URLByAppendingPathComponent:@"CoreDataDemo.sqlite"];
    
    NSError *error = nil;
    _persistentStoreCoordinator = [[NSPersistentStoreCoordinator alloc] initWithManagedObjectModel:[self managedObjectModel]];
    if (![_persistentStoreCoordinator addPersistentStoreWithType:NSSQLiteStoreType configuration:nil URL:storeURL options:nil error:&error]) {
        /*
         Replace this implementation with code to handle the error appropriately.
         
         abort() causes the application to generate a crash log and terminate. You should not use this function in a shipping application, although it may be useful during development.
         
         Typical reasons for an error here include:
         * The persistent store is not accessible;
         * The schema for the persistent store is incompatible with current managed object model.
         Check the error message to determine what the actual problem was.
         
         
         If the persistent store is not accessible, there is typically something wrong with the file path. Often, a file URL is pointing into the application's resources directory instead of a writeable directory.
         
         If you encounter schema incompatibility errors during development, you can reduce their frequency by:
         * Simply deleting the existing store:
         [[NSFileManager defaultManager] removeItemAtURL:storeURL error:nil]
         
         * Performing automatic lightweight migration by passing the following dictionary as the options parameter:
         @{NSMigratePersistentStoresAutomaticallyOption:@YES, NSInferMappingModelAutomaticallyOption:@YES}
         
         Lightweight migration will only work for a limited set of schema changes; consult "Core Data Model Versioning and Data Migration Programming Guide" for details.
         
         */
        NSLog(@"Unresolved error %@, %@", error, [error userInfo]);
        abort();
    }
    
    return _persistentStoreCoordinator;
}

#pragma mark - Application's Documents directory

// Returns the URL to the application's Documents directory.
- (NSURL *)applicationDocumentsDirectory
{
    return [[[NSFileManager defaultManager] URLsForDirectory:NSDocumentDirectory inDomains:NSUserDomainMask] lastObject];
}


@end
