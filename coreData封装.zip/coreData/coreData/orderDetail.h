//
//  orderDetail.h
//  coreData
//
//  Created by cbwl on 16/12/9.
//  Copyright © 2016年 CYT. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface orderDetail : NSObject
@property (  nonatomic, copy) NSString *address;
@property (  nonatomic, copy) NSString *age;
@property (  nonatomic, copy) NSString *better;
@property (  nonatomic, copy) NSString *height;
@property (  nonatomic, copy) NSString *name;
@end
