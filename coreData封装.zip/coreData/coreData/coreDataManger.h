//
//  coreDataManger.h
//  coreData
//
//  Created by cbwl on 16/12/9.
//  Copyright © 2016年 CYT. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <CoreData/CoreData.h>
#import "OrderDetail+CoreDataProperties.h"

@interface coreDataManger : NSObject

//管理对象上下文：相对于数据库本身
@property ( strong, nonatomic) NSManagedObjectContext *managedObjectContext;
//xcdatamodel
@property ( strong, nonatomic) NSManagedObjectModel *managedObjectModel;
//中转站

@property ( strong, nonatomic) NSPersistentStoreCoordinator *persistentStoreCoordinator;

///修改数据
-(void)changeCoreDataMsg:(NSString *)orderId;
///删除   orderId  关键词
-(void)delectManager:(NSString *)orderId;
///添加到数据库
-(void)insertCoreDataObjectWithOrder:(OrderDetail *)order;
///查询
-(void)lookCoreData;

+(instancetype)shareinstance;
@end
