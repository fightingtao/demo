//
//  OrderDetail+CoreDataClass.h
//  coreData
//
//  Created by cbwl on 16/12/9.
//  Copyright © 2016年 CYT. All rights reserved.
//  This file was automatically generated and should not be edited.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

NS_ASSUME_NONNULL_BEGIN

@interface OrderDetail : NSManagedObject

@end

NS_ASSUME_NONNULL_END

#import "OrderDetail+CoreDataProperties.h"
