//
//  OrderDetail+CoreDataProperties.m
//  coreData
//
//  Created by cbwl on 16/12/9.
//  Copyright © 2016年 CYT. All rights reserved.
//  This file was automatically generated and should not be edited.
//

#import "OrderDetail+CoreDataProperties.h"

@implementation OrderDetail (CoreDataProperties)

+ (NSFetchRequest<OrderDetail *> *)fetchRequest {
	return [[NSFetchRequest alloc] initWithEntityName:@"OrderDetail"];
}

@dynamic address;
@dynamic age;
@dynamic better;
@dynamic height;
@dynamic name;

@end
