package com.alibaba.media.sdk.demo;

import android.app.Application;
import android.util.Log;

import com.alibaba.sdk.android.AlibabaSDK;
import com.alibaba.sdk.android.callback.InitResultCallback;
import com.alibaba.sdk.android.media.MediaService;

/**
 * @Description info
 * @author yisheng.xp
 * @date 2015年9月24日 下午2:13:22
 */
public class DemoApp extends Application {

	public static final String NAMESPACE = "<Your namespace>";
	public static MediaService mediaService;

	private static final String TAG = "DemoApp";

	@Override
	public void onCreate() {
		super.onCreate();
		initAlibabaSDK();
		AlibabaSDK.turnOnDebug();
	}

	public void initAlibabaSDK() {
		MediaService.enableHttpDNS(); //如果用户为了避免域名劫持，可以启用HttpDNS
		MediaService.enableLog(); //在调试时，可以打印日志。正式上线前可以关闭
		AlibabaSDK.asyncInit(this, new InitResultCallback() {
			@Override
			public void onSuccess() {
				Log.i(TAG, "AlibabaSDK   onSuccess");
				mediaService = AlibabaSDK.getService(MediaService.class);
			}

			@Override
			public void onFailure(int code, String msg) {
				Log.e(TAG, "AlibabaSDK onFailure  msg:" + msg + " code:" + code);
			}
		});
	}
}
