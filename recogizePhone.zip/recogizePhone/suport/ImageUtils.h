// Copyright (С) ABBYY (BIT Software), 1993 - 2012. All rights reserved. 

#ifndef IMAGE_UTILS_H
#define IMAGE_UTILS_H

#import <UIKit/UIKit.h>

UIImage *scaleAndRotateImage(UIImage *image, int maxPixelsAmount);

#endif // IMAGE_UTILS_H
