//
//  ViewController.h
//  recogizePhone
//
//  Created by cbwl on 16/12/7.
//  Copyright © 2016年 CYT. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

