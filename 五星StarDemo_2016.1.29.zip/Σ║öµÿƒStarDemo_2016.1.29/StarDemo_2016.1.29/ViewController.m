//
//  ViewController.m
//  StarDemo_2016.1.29
//
//  Created by 张重 on 16/1/29.
//  Copyright © 2016年 张重. All rights reserved.
//

#import "ViewController.h"
#import "StarView.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    StarView *starV = [[StarView alloc]initWithFrame:CGRectMake(20, 200, 200, 50)];
    starV.font_size = 20;
//    starV.full_color
//    starV.empty_color
    starV.show_star = 40;
    starV.canSelected = YES;
    [self.view addSubview:starV];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

@end
