//
//  AppDelegate.h
//  StarDemo_2016.1.29
//
//  Created by 张重 on 16/1/29.
//  Copyright © 2016年 张重. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

