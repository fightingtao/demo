
#import <UIKit/UIKit.h>

@interface UITextField (LXExtension)
/** 占位文字颜色 */
@property (nonatomic, strong) UIColor *lx_placeholderColor;
@end
