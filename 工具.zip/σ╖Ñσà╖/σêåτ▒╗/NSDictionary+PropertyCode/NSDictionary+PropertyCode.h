
#import <Foundation/Foundation.h>

@interface NSDictionary (PropertyCode)

// 生成所需要的属性代码
- (void)propertyCode;

@end
