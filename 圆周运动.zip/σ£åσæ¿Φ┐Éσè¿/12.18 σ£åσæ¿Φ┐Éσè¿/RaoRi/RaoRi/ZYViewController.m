//
//  ZYViewController.m
//  RaoRi
//
//  Created by BaiShuang on 15/12/18.
//  Copyright (c) 2015年 ZhiYou. All rights reserved.
//

#import "ZYViewController.h"
#import "ZYImageView.h"
@interface ZYViewController ()

@end

@implementation ZYViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    _imgviewSun = [[UIImageView alloc]init];
    _imgviewSun.bounds = CGRectMake(0, 0, 100, 100);
    _imgviewSun.center = CGPointMake(160, 240);
    _imgviewSun.image = [UIImage imageNamed:@"sun.png"];
    [self.view addSubview:_imgviewSun];
    
    _arrayEarths = [[NSMutableArray alloc]init];
    for (int i = 0; i < 9; i ++) {
        float centerX = _imgviewSun.center.x + 150*cos(i*40*M_PI/180);
        float centerY = _imgviewSun.center.y + 50*sin(i*40*M_PI/180);
        
        ZYImageView *imgviewEarth = [[ZYImageView alloc]init];
        imgviewEarth.bounds = CGRectMake(0, 0, 40, 40);
        imgviewEarth.center = CGPointMake(centerX, centerY);
        imgviewEarth.image = [UIImage imageNamed:@"earth.png"];
        
        imgviewEarth.angle = i*40;
        
        [self.view addSubview:imgviewEarth];
        
        [_arrayEarths addObject:imgviewEarth];

    }
    
    [NSTimer scheduledTimerWithTimeInterval:0.1 target:self selector:@selector(onTimer:) userInfo:nil repeats:YES];
    
    
	// Do any additional setup after loading the view, typically from a nib.
}

-(void)onTimer:(NSTimer *)timer {
    
    for (ZYImageView *imgviewEarth in _arrayEarths) {
        //获取 imgviewEarth 当前的角度
        imgviewEarth.angle += 3;

        float centerX = _imgviewSun.center.x + 150*cos(imgviewEarth.angle*M_PI/180);
        float centerY = _imgviewSun.center.y + 50*sin(imgviewEarth.angle*M_PI/180);
        
        imgviewEarth.center = CGPointMake(centerX, centerY);

        if (imgviewEarth.angle >= 360 ) {
            imgviewEarth.angle = (int)imgviewEarth.angle%360;
        }
        
        
        if (_imgviewSun.center.y <= imgviewEarth.center.y) {
            [self.view bringSubviewToFront:imgviewEarth];
        }
        else {
            [self.view sendSubviewToBack:imgviewEarth];
        }
        
        
    }
    
    
    
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end







