//
//  ZYImageView.h
//  RaoRi
//
//  Created by BaiShuang on 15/12/18.
//  Copyright (c) 2015年 ZhiYou. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ZYImageView : UIImageView

//添加属性angle来记录地球当前的角度位置
@property (nonatomic, assign) float angle;

@end
