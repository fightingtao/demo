//
//  ZYViewController.m
//  YuanZhou
//
//  Created by BaiShuang on 15/12/18.
//  Copyright (c) 2015年 ZhiYou. All rights reserved.
//

#import "ZYViewController.h"

@interface ZYViewController ()

@end

@implementation ZYViewController

//NSTimer(来实现动画)
//UIView(属性动画,过渡动画)
//帧动画 UIImageView
//自转(NSTimer + transform)
//圆周运动,椭圆运动
- (void)viewDidLoad
{
    [super viewDidLoad];
	
    [self testZiZhuan];
    
    [self testYuanZhou];
}
/*
 圆周运动公式:
 顺时针
 x:centerX + R*cosA
 y:centerY + R*sinA
 
 逆时针
 x:centerX + R*cosA
 y:centerY - R*sinA
 
 椭圆运动
 顺时针
 x:centerX + 长半轴*cosA
 y:centerY + 短半轴*sinA
 
 逆时针
 
 x:centerX + 长半轴*cosA
 y:centerY - 短半轴*sinA
 
 
 
 */

-(void)testYuanZhou {
    //太阳
    UIImageView *imgviewSun = [[UIImageView alloc]init];
    imgviewSun.bounds = CGRectMake(0, 0, 100, 100);
    imgviewSun.center = CGPointMake(160, 240);
    imgviewSun.image = [UIImage imageNamed:@"sun.png"];
    [self.view addSubview:imgviewSun];
    imgviewSun.tag = 100;
    
    //地球的
    UIImageView *imgviewEarth = [[UIImageView alloc]init];
    imgviewEarth.bounds = CGRectMake(0, 0, 30, 30);
    
    float x = imgviewSun.center.x + 100*cos(90*M_PI/180);
    float y = imgviewSun.center.y - 50*sin(90*M_PI/180);
    
    imgviewEarth.center = CGPointMake(x, y);
    imgviewEarth.image = [UIImage imageNamed:@"earth.png"];
    [self.view addSubview:imgviewEarth];
    
    
    [NSTimer scheduledTimerWithTimeInterval:4 target:self selector:@selector(onTimerYuanZhou:) userInfo:imgviewEarth repeats:YES];

}


-(void)onTimerYuanZhou:(NSTimer *)timer {
    
    //地球的中心点
    //centerX + R*cosA
    //centerY + R*sinA
    
    UIImageView *imgviewEarth = timer.userInfo;
    
    
    UIImageView *imgview = (UIImageView *)[self.view viewWithTag:100];

    static int angle = 0;

    angle += 3;
    
    float x =  imgview.center.x + 100*cos(angle*M_PI/180);
    float y =  imgview.center.y - 50*sin(angle*M_PI/180);
    
    imgviewEarth.center = CGPointMake(x, y);
    
    if (angle>360) {
        angle = angle%360;
    }
}


#pragma mark - 自转

-(void)testZiZhuan {
    UIImageView *imgview = [[UIImageView alloc]init];
    
    imgview.frame = CGRectMake(0, 0, 50, 50);
    imgview.image = [UIImage imageNamed:@"earth.png"];
    [self.view addSubview:imgview];
    
    [NSTimer scheduledTimerWithTimeInterval:0.1 target:self selector:@selector(onTimer:) userInfo:imgview repeats:YES];

}

-(void)onTimer:(NSTimer *)timer {
    
    UIImageView *imgview = timer.userInfo;
    
    static int angle = 0;
    angle += 3;
    
    imgview.transform = CGAffineTransformMakeRotation(angle*M_PI/180);
    
    if (angle>= 360) {
        angle = angle%360;
    }
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
