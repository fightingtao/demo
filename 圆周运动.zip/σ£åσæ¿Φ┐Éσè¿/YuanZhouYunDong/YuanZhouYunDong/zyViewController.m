//
//  zyViewController.m
//  YuanZhouYunDong
//
//  Created by 付耿臻 on 15-12-18.
//  Copyright (c) 2015年 zhiyou. All rights reserved.
//

#import "zyViewController.h"

@interface zyViewController ()
{
    UIButton *_btnStart;
    NSTimer *_timer;
    NSMutableArray *_array;
}
@end

@implementation zyViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    [self yuanZhou];
    UIButton *btnStart=[UIButton buttonWithType:UIButtonTypeSystem];
    btnStart.frame=CGRectMake(0, 50, 50, 50);
    [btnStart setTitle:@"暂停" forState:UIControlStateNormal];
    [btnStart addTarget:self action:@selector(onButtonClick2) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btnStart];
    _btnStart=btnStart;

    
}
-(void)onButtonClick2{
    
    if ([_btnStart.titleLabel.text isEqualToString:@"开始" ]) {
        [_btnStart setTitle:@"暂停" forState:UIControlStateNormal];
        
        //开始定时器
        
        [_timer setFireDate:[NSDate date]];
        
        
        
        
    }
    if ([_btnStart.titleLabel.text isEqualToString:@"暂停" ]) {
        [_btnStart setTitle:@"开始" forState:UIControlStateNormal];
        
        //暂停定时器
        
        [_timer setFireDate:[NSDate distantFuture]];
        
    }
    
    
}
-(void)yuanZhou{
    UIImageView *imageCenter=[[UIImageView alloc]init];
    imageCenter.frame=CGRectMake(100, 200, 70, 70);
    imageCenter.image=[UIImage imageNamed:@"Hustler_065.jpg"];
    [self.view addSubview:imageCenter];
    
    
    NSMutableArray *array=[[NSMutableArray alloc]init];
    

    for (int j=0; j<9; j++) {
        static int i=0;
        UIImageView *imageRun=[[UIImageView alloc]init];
        imageRun.image=[UIImage imageNamed:@"08583771"];
        imageRun.bounds=CGRectMake(0, 0, 20, 20);

        imageRun.center=CGPointMake(imageCenter.center.x+100*cos(i*40*M_PI/180), imageCenter.center.y +100*sin(i*40*M_PI/180));
        i++;

    imageRun.tag=100;
        [array addObject:imageRun];
        _array=array;
    [self.view addSubview:imageRun];

   _timer =[NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(run:) userInfo:imageCenter repeats:YES];
   }
}
-(void )run:(NSTimer *)timer{
    UIImageView *imageCenter=timer.userInfo;
//    UIImageView *imageRun=(UIImageView *)[self.view viewWithTag:100];
    for (UIImageView *imageRun in _array) {
        
    
   static int  i=0;
    
    i++;

    static int angle=0;
//    if (angle>360) {
//        angle=0;
//    
//    }
    angle+=3;

   
        if ((i*40+angle)>180) {
       // [self.view addSubview:imageRun];
            float x=imageCenter.center.x+100*cos(((i*40+angle)%360)*M_PI/180);
            float y=imageCenter.center.y+100*sin(((i*40+angle)%360)*M_PI/180);
            imageRun.center=CGPointMake(x, y);

    [self.view addSubview:imageCenter];
    }
    else{
        
    [self.view sendSubviewToBack:imageCenter];
    
    }
        if (i>9) {
            i=0;
            
        }

    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
