//
//  main.m
//  YuanZhouYunDong
//
//  Created by 付耿臻 on 15-12-18.
//  Copyright (c) 2015年 zhiyou. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "zyAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([zyAppDelegate class]));
    }
}
