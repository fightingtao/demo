//
//  ZYViewController.m
//  HuaMeiGui
//
//  Created by BaiShuang on 15/12/18.
//  Copyright (c) 2015年 ZhiYou. All rights reserved.
//

#import "ZYViewController.h"

@interface ZYViewController ()

@end

@implementation ZYViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    UIImageView *imgview = [[UIImageView alloc]init];
    imgview.frame = [[UIScreen mainScreen]bounds];
    imgview.image = [UIImage imageNamed:@"animal.png"];
    [self.view addSubview:imgview];
    
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeSystem];
    btn.frame = CGRectMake(0, 20, 50, 50);
    [btn setTitle:@"清理" forState:UIControlStateNormal];
    
    [btn addTarget:self action:@selector(onClearButtonClick) forControlEvents:UIControlEventTouchUpInside];
    
    [self.view addSubview:btn];
    
    
    _array = [[NSMutableArray alloc]init];
    for (int i = 1; i <= 11 ; i ++) {
        NSString *str = [NSString stringWithFormat:@"%d.png",i];
        [_array addObject:[UIImage imageNamed:str]];
    }
    
	// Do any additional setup after loading the view, typically from a nib.
}

//当在屏幕中拖动鼠标时,这个方法会被触发
//touch 触摸 event
//NSSet 集合 容器(NSArray NSDictionary)
-(void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event {
    
    //控制种玫瑰的频率
    //记录此方法被执行的次数
    static int count = 0;
    count ++;
    NSLog(@"toucheMove");
    if (count%6 != 0) {
        //不种玫瑰
        return;
    }
    NSLog(@"种玫瑰");
    //count%6 == 0 种玫瑰
    
    //    NSLog(@"toucheMove");
    //touches -- > 触摸点 --- > CGPoint
    //event
    
    //获取触摸点
    //touches NSSet
    
    //    id aTouch = [touches anyObject];
    //在集合touches中存放了很多UITouch对象
    UITouch *aTouch = [touches anyObject];
    //    NSLog(@"%@",aTouch);
    
    
    //location 位置
    CGPoint point = [aTouch locationInView:self.view];
    NSLog(@"%@",NSStringFromCGPoint(point));
    
    
    
    UIImageView *imgview = [[UIImageView alloc]init];
    imgview.bounds = CGRectMake(0, 0, 30, 30);
    imgview.center = point;
    imgview.animationImages = _array;
    imgview.animationDuration = 2;
    imgview.animationRepeatCount = 0;
    [self.view addSubview:imgview];
    imgview.tag = 100;
    
    [imgview startAnimating];

    
}


-(void)onClearButtonClick {
    NSArray *array = [self.view subviews];
    for (UIView *view in array) {
        if (view.tag == 100) {
            [view removeFromSuperview];
        }
    }
    
}

//比较两个frame是否相等
//    CGRectEqualToRect(<#CGRect rect1#>, <#CGRect rect2#>)

//一个矩形区域是否包含一个点
//    CGRectContainsPoint(<#CGRect rect#>, <#CGPoint point#>)
//两个矩形区域是否相交
//    CGRectIntersectsRect(<#CGRect rect1#>, <#CGRect rect2#>)


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end






