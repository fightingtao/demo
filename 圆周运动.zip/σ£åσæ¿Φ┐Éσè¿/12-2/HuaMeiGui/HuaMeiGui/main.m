//
//  main.m
//  HuaMeiGui
//
//  Created by BaiShuang on 15/12/18.
//  Copyright (c) 2015年 ZhiYou. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "ZYAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([ZYAppDelegate class]));
    }
}
