//
//  ZYViewController.m
//  Tomcat
//
//  Created by BaiShuang on 15/12/18.
//  Copyright (c) 2015年 ZhiYou. All rights reserved.
//

#import "ZYViewController.h"

@interface ZYViewController ()

@end

@implementation ZYViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    //
    UIImageView *imgview = [[UIImageView alloc]init];
    imgview.frame = [[UIScreen mainScreen]bounds];
    imgview.image = [UIImage imageNamed:@"cymbal_00.jpg"];
    [self.view addSubview:imgview];
    _imgview = imgview;
    
    _arrayBtn = [[NSMutableArray alloc]init];
    for (int i = 0; i < 6; i ++) {
        UIButton *btn = [UIButton buttonWithType:UIButtonTypeSystem];
        
        float x = 20 + (60+160)*(i%2);
        float y = 200 + (60 + 40)*(i/2);
        
        btn.frame = CGRectMake(x, y, 60, 60);
        
        NSString *imgStr = [NSString stringWithFormat:@"tomButton%d.png",i+1];
        
        [btn setBackgroundImage:[UIImage imageNamed:imgStr] forState:UIControlStateNormal];
        
        [btn addTarget:self action:@selector(onButtonClick:) forControlEvents:UIControlEventTouchUpInside];
        btn.tag = i + 1;
        
        [self.view addSubview:btn];
        
        [_arrayBtn addObject:btn];
        
    }
    
    //整合图片资源
    _arrayData = [[NSMutableArray alloc]init];
  
    // 12 80 39 27 23 55
    NSArray *arrayIndex = @[@"12",@"80",@"39",@"27",@"23",@"55"];
    
    //cymbal drink eat fart pie scratch
    NSArray *arrayNamePrefix = @[@"cymbal",@"drink",@"eat",@"fart",@"pie",@"scratch"];
    
    for (int i = 0; i < 6; i ++) {
        //盛放每组图片的数组
        NSMutableArray *arrayPer = [[NSMutableArray alloc]init];
        
        int indexCount = [arrayIndex[i] intValue];
        NSString *namePrefix = arrayNamePrefix[i];
        
        for (int j = 0; j <= indexCount ; j ++) {
            
            NSString *imgStr = [NSString stringWithFormat:@"%@_%.2d.jpg",namePrefix,j];
            
            [arrayPer addObject:[UIImage imageNamed:imgStr]];
        }
        
        
        
        [_arrayData addObject:arrayPer];

    }
    
//    NSLog(@"%@",_arrayData);
    
    /*
    NSMutableArray *array1 = [[NSMutableArray alloc]init];

    for (int i = 0; i <= 12 ; i ++) {
        NSString *imgStr = [NSString stringWithFormat:@"cymbal_%.2d.jpg",i];
        [array1 addObject:imgStr];
    }
    
    [_arrayData addObject:array1];
    
    
    NSMutableArray *array2 = [[NSMutableArray alloc]init];
    
    for (int i = 0; i <= 80 ; i ++) {
        NSString *imgStr = [NSString stringWithFormat:@"drink_%.2d.jpg",i];
        [array2 addObject:imgStr];
    }
    
    [_arrayData addObject:array2];
    
    */
    
	// Do any additional setup after loading the view, typically from a nib.
}

-(void)onButtonClick:(UIButton *)btn {
    
    NSArray *array = _arrayData[btn.tag-1];
    
    _imgview.animationImages = array;
    _imgview.animationDuration = array.count*0.1;
    _imgview.animationRepeatCount = 1;
    
    [_imgview startAnimating];
    
    
    [self hiddenButtons];
    
    [self performSelector:@selector(showButtons) withObject:nil afterDelay:_imgview.animationDuration];
}




-(void)showButtons {
    for (UIButton *btn in _arrayBtn) {
        btn.hidden = NO;
    }
}

-(void)hiddenButtons {
//    for (int i = 0; i < 6; i ++) {
//        UIButton *btn = (UIButton *)[self.view viewWithTag:i + 1];
//        btn.hidden = YES;
//    }
    
    for (UIButton *btn in _arrayBtn) {
        btn.hidden = YES;
    }
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
