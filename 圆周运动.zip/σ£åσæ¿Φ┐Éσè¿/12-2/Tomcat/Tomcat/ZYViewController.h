//
//  ZYViewController.h
//  Tomcat
//
//  Created by BaiShuang on 15/12/18.
//  Copyright (c) 2015年 ZhiYou. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ZYViewController : UIViewController
{
    UIImageView *_imgview;
    
    NSMutableArray *_arrayBtn;
    
    //大的,总的数组
    NSMutableArray *_arrayData;
}
@end
